GGR321 A2 Yilan Hong 1010259480

ATBX File titled "GGR321 A2 Yilan Hong 1010259480" Contains the model builder made for question 2 of the assignment.

File folder titled "Map Outputs" contains pdf and jpeg files of all maps/diagrams/images generated for the assignment requirements:
	-> "A2 Model Builder" - Exported diagram of least cost path analysis model builder
	
	-> "Candidate Spot A Map"
	   "Candidate Spot B Map" - 3 separate viewshed maps for question 1
	   "Candidate Spot C Map"
	
	-> "finalcost"
	   "landcost" - Exported raster layers for each part of the 3-panel map
	   "slopecost"
	
	-> "Three Panel Map" - Final 3-panel map